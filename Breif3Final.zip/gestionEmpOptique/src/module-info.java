module gestionEmpOptique {
}