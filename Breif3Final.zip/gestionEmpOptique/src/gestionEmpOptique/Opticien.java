package gestionEmpOptique;

public class Opticien extends Personne {

	public Opticien(String nom, int age) {
		super(nom, age);
		// TODO Auto-generated constructor stub
	}
	

	public void afficher() {
		
		System.out.println(" Je suis "+ getNom() + " j�ai " + getAge() +" ans et je travaille en tant que opticienne !");
		

}
}
